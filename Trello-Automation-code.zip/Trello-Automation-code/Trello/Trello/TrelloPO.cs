﻿using OpenQA.Selenium;
using System;
using System.Text;
using System.Threading;

namespace Trello
{
    public class TrelloPO
    {
        /*This method is enabled to send userid for login*/
        public void LocateUser(IWebDriver driver, string userid)
        {
            driver.FindElement(By.Id("user")).SendKeys(userid);
        }

        /*This method is enabled to allow login button*/
        public void ClickLoginbutton(IWebDriver driver)
        {
            driver.FindElement(By.Id("login")).Click();
        }

        /*This method is enabled to enter password*/
        public void LocatePwd(IWebDriver driver, string password)
        {
            Thread.Sleep(5000);
            IWebElement element = driver.FindElement(By.XPath("//*[@id='password']"));
            element.SendKeys(password);
        }

        /*This method is enabled to click on final login button*/
        public void ClickLoginbuttonSubmit(IWebDriver driver)
        {
            driver.FindElement(By.CssSelector("#login-submit > span > span")).Click();
        }

        /*This method is enabled to click logout and close window*/
        public void ClickLogoutandwindowclose(IWebDriver driver)
        {
            driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[1]/div[2]/div[1]/div/div/div[2]/button[3]")).Click();
            driver.FindElement(By.XPath("/html/body/div[2]/div[2]/section/div/nav/ul/li[8]/button/span"));
        }

        /*This method is enabled to click on the board in trello*/
        public void ClickBoard(IWebDriver driver,string boardtitle)
        {
            Thread.Sleep(5000);
            string defaultxpath = "//*[@id='content']/div/div[2]/div/div/div/div/div[2]/div/div/div[2]/div[2]/ul/li[1]/a/div";

            for (int i = 1; i <= 9; i++)
            {

                string rpstring = defaultxpath;
                StringBuilder sr = new StringBuilder(rpstring);

                string stri = i.ToString();
                char chari = Convert.ToChar(stri);

                sr[81] = chari;
                string checkxpath = sr.ToString();
                var boardelementtext = driver.FindElement(By.XPath(checkxpath)).Text;
                var boardelement = driver.FindElement(By.XPath(checkxpath));
                if (boardelementtext.Contains(boardtitle))
                {
                    boardelement.Click();
                    i = 10;
                }
            }
        }

        /*This method is enabled to add new list on board*/
        public void CreatenewList(IWebDriver driver)
        {
            Thread.Sleep(3000);
            driver.FindElement(By.ClassName("placeholder")).Click();
            driver.FindElement(By.ClassName("list-name-input")).SendKeys("New list...");
            driver.FindElement(By.CssSelector(".mod-list-add-button")).Click();
            driver.FindElement(By.CssSelector("#board > div.js-add-list.list-wrapper.mod-add > form > div > a")).Click();
        }

        /*This method is enabled to add items in the List-1 on board*/
        public void AddcardList1(IWebDriver driver)
        {
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("//*[@id='board']/div[1]/div/div[3]/a/span[2]")).Click();
            driver.FindElement(By.ClassName("list-card-composer-textarea")).SendKeys("Add to card for List 1");
            driver.FindElement(By.ClassName("nch-button")).Click();
        }

        /*This method is enabled to delete card on list*/
        public void deleteCard(IWebDriver driver)
        {
            Thread.Sleep(3000);
            /*click on the first item on the board item on the board*/
            driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[1]/div[2]/main/div/div/div[3]/div/div[1]/div[3]/div[2]/div[1]/div/div[2]/a/div[3]/span")).Click();

            /*click on the archive button*/
            driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[3]/div/div/div/div[5]/div[5]/div/a[5]")).Click();

            /*click on the delete button*/
            driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[3]/div/div/div/div[5]/div[5]/div/a[7]")).Click();

            /*click on the accept to OK pop-up */
            driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[4]/div/div[2]/div/div/div/input")).Click();
        }

        public void deleteList(IWebDriver driver)
        {
            Thread.Sleep(3000);
            driver.FindElement(By.XPath("/html/body/div[1]/div[2]/div[1]/div[2]/main/div/div/div[3]/div/div[1]/div[3]/div[2]/div[1]/div/div[1]/div[2]/a")).Click();
            driver.FindElement(By.ClassName("js-close-list")).Click();
        }
    }
}
