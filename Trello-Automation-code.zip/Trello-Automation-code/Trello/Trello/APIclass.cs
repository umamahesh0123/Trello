﻿using System;
using Newtonsoft.Json;
using RestSharp;
using System.Net;
using NUnit.Framework;
using Newtonsoft.Json.Linq;
using System.Diagnostics;

namespace Trello_API
{
    public class APIs
    {
        string token = "a24bb241e22a4271274244ccf0353b9b1f1a70b6fdff0d438ce46bdb346e3523";
        string key = "52347ed89fdfb38652b527a99169cfd9";

        public static RestClient RestClient { get; set; }
        public static IRestResponse Reponse { get; set; }
        public static RestRequest RestRequest { get; set; }
        public string id { get; set; }
        public string listid { get; set; }

        public void InitialiseNewboardEndpoint()
        {
            RestClient = new RestClient();
            RestRequest = new RestRequest("https://api.trello.com/1/boards/?name=APIBoard-2", Method.POST);
        }
        public void TrelloEndpoint()
        {
            var endpointUri = new Uri("https://api.trello.com/");
            RestClient.BaseUrl = endpointUri;
        }
        public void SendGetInfoRequest()
        {
            RestRequest.AddQueryParameter("key", key);
            RestRequest.AddQueryParameter("token", token);
            Reponse = RestClient.Execute(RestRequest);

            JObject result = JObject.Parse(Reponse.Content);

            id = (string)result["id"];
        }
        public void ValidateResponse()
        {
            Assert.AreEqual(HttpStatusCode.OK, Reponse.StatusCode);
        }

        public void InitialiseNewListEndpoint()
        {
            RestClient = new RestClient();
            RestRequest = new RestRequest("https://api.trello.com/1/lists", Method.POST);
            RestRequest.AddQueryParameter("name", "APIList");
            RestRequest.AddQueryParameter("idBoard", id);
        }

        public void InitialiseNewCardEndpoint()
        {
            listid = id;
            RestClient = new RestClient();
            RestRequest = new RestRequest("https://api.trello.com/1/cards", Method.POST);
            RestRequest.AddQueryParameter("name", "APICard");
            RestRequest.AddQueryParameter("idList", id);
        }
        public void InitialiseDeleteAllCardEndpoint()
        {
            RestClient = new RestClient();
            RestRequest = new RestRequest("https://api.trello.com/1/lists/" + listid + "/archiveAllCards?", Method.POST);
        }
    }
}

