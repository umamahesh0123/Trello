﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Threading;
using TechTalk.SpecFlow;

namespace Trello.Specs.Steps
{

    [Binding]
    public sealed class TrelloPOStepDefinitions
    {

        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly ScenarioContext _scenarioContext;

        TrelloPO lp = new TrelloPO();
        IWebDriver driver = new ChromeDriver("C:/Users/sukku/Downloads/chromedriver_win32 (1)");
  
        public TrelloPOStepDefinitions(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given("Visit Trello Loginpage")]
        public void Loginpage()
        {
            driver.Navigate().GoToUrl("http://trello.com/login");
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
        }

        [Given("Login to Trello & navigate to Myboard")]
        public void LogintoTrelloandnavigatetobaord()
        {
                driver.Navigate().GoToUrl("https://trello.com/login");
                driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);

                string userid = "umamahesh0123@gmail.com";
                lp.LocateUser(driver, userid);
                lp.ClickLoginbutton(driver);

                string password = "Sevya@22";
                lp.LocatePwd(driver, password);
                lp.ClickLoginbuttonSubmit(driver);

                string boardtitle = "Myboard";
                lp.ClickBoard(driver, boardtitle);
         }

        [Then("create new list")]
        public void creatlist()
        {
            lp.CreatenewList(driver);
        }

        [Then("add card to list")]
        public void addcardtolist()
        {
            lp.AddcardList1(driver);
        }

        [Then("delete card")]
        public void deletecard()
        {
            lp.deleteCard(driver);
        }

        [Then("delete list")]
        public void deletelist()
        {
            lp.deleteList(driver);
        }
    }
}
