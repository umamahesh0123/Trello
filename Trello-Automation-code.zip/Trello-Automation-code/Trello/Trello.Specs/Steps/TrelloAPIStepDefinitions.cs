﻿using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;
using Trello_API;

namespace Trello.Specs.Steps
{
    [Binding]
    public sealed class TrelloAPIStepDefinitions
    {

        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly ScenarioContext _scenarioContext;

        APIs api = new APIs();

        public TrelloAPIStepDefinitions(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given("Newboard Send request and receive response")]
        public void Newboard()
        {
            api.InitialiseNewboardEndpoint();
            api.TrelloEndpoint();
            api.SendGetInfoRequest();
        }

        [Given("Newlist Send request and receive response")]
        public void Newlist()
        {
            api.InitialiseNewListEndpoint();
            api.TrelloEndpoint();
            api.SendGetInfoRequest();
        }

        [Given("Newcard Send request and receive response")]
        public void Newcard()
        {
            api.InitialiseNewCardEndpoint();
            api.TrelloEndpoint();
            api.SendGetInfoRequest();
        }

        [Given("Allcard Send request and receive response")]
        public void Allcarddelete()
        {
            api.InitialiseDeleteAllCardEndpoint();
            api.TrelloEndpoint();
            api.SendGetInfoRequest();
        }

        [Then("validate the response")]
        public void validateresponse()
        {
            api.ValidateResponse();
        }
    }
}
